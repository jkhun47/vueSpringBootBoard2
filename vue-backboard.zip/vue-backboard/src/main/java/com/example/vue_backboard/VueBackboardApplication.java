package com.example.vue_backboard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VueBackboardApplication {

	public static void main(String[] args) {
		SpringApplication.run(VueBackboardApplication.class, args);
	}

}
